//
//  StudentEntryViewController.swift
//  MidTerm_MADF2017
//
//  Created by moxDroid on 2017-10-20.
//  Copyright © 2017 moxDroid. All rights reserved.
//  Student ID :
//  Student Name :

import UIKit

class StudentEntryViewController: UIViewController {

    @IBOutlet weak var txtFieldID : UITextField!
    @IBOutlet weak var txtFieldName : UITextField!
    @IBOutlet weak var txtFieldEmailId : UITextField!
    @IBOutlet weak var txtFieldBirthdate : UITextField!
    @IBOutlet weak var txtFieldSubject1 : UITextField!
    @IBOutlet weak var txtFieldSubject2 : UITextField!
    @IBOutlet weak var txtFieldSubject3 : UITextField!
    @IBOutlet weak var txtFieldSubject4 : UITextField!
    @IBOutlet weak var txtFieldSubject5 : UITextField!
    
    var datePicker:UIDatePicker!
    var student: Student!
    var studentAlreadyExisted: Student!
    var birthdate:String!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let logout = UIBarButtonItem(title: "Logout", style: .plain, target: self, action: #selector(logoutTapped))
        self.navigationItem.leftBarButtonItem = logout
        
        self.navigationController?.navigationBar.isHidden = false
        
        datePicker = UIDatePicker.init()
        datePicker.date = Date()
        datePicker.addTarget(self, action: #selector(dateChangeTapped), for: .valueChanged)
        datePicker.maximumDate = Calendar.current.date(byAdding: .day, value: -1, to: Date())

        txtFieldBirthdate.inputView = datePicker
        
        if studentAlreadyExisted != nil {
            txtFieldID.text = studentAlreadyExisted.studentId!
            txtFieldName.text = studentAlreadyExisted.studentName!
            txtFieldEmailId.text = studentAlreadyExisted.studentEmail!
            txtFieldBirthdate.text = studentAlreadyExisted.studentBirthdate!
            txtFieldSubject1.text = String(studentAlreadyExisted.subject1!)
            txtFieldSubject2.text = String(studentAlreadyExisted.subject2!)
            txtFieldSubject3.text = String(studentAlreadyExisted.subject3!)
            txtFieldSubject4.text = String(studentAlreadyExisted.subject4!)
            txtFieldSubject5.text = String(studentAlreadyExisted.subject5!)
        }
    }

    @objc func dateChangeTapped() {
        let picker:UIDatePicker = txtFieldBirthdate.inputView as! UIDatePicker
        print(picker.date)
        let calendar = Calendar.current
        
        let year = calendar.component(.year, from: picker.date)
        let month = calendar.component(.month, from: picker.date)
        let day = calendar.component(.day, from: picker.date)

        txtFieldBirthdate.text = String.init(describing: "\(day)-\(month)-\(year)")
    }
    
    @objc func logoutTapped() {
        flushEmailInUserDefaults()
        let storyboard : UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let vc : LoginViewController = storyboard.instantiateViewController(withIdentifier: "loginVC") as! LoginViewController
        let navigationController = UINavigationController(rootViewController: vc)
        self.present(navigationController, animated: true, completion: nil)
    }
    
    func flushEmailInUserDefaults() {
        let userDefaults = UserDefaults.standard
        userDefaults.removeObject(forKey: "email")
        userDefaults.synchronize()
    }
    
    @IBAction func btnAddStudentTapped(sender:UIButton) {
            validatingFields()
    }
    
    func validatingFields() {
        if !(txtFieldID.text?.hasPrefix("C"))! {
            showAlertMessage(message: "Student ID must contains first letter C")
        }
        else if !isValidEmail(testStr: txtFieldEmailId.text!) {
            showAlertMessage(message: "Email Id is not valid.")
        }
        else {
            student = Student.init(txtFieldID.text!, txtFieldName.text!, txtFieldEmailId.text!, txtFieldBirthdate.text!, NSString(string: txtFieldSubject1.text!).floatValue, NSString(string: txtFieldSubject2.text!).floatValue, NSString(string: txtFieldSubject3.text!).floatValue, NSString(string: txtFieldSubject4.text!).floatValue, NSString(string: txtFieldSubject5.text!).floatValue)
            self.performSegue(withIdentifier: "resultsegue", sender: self)
        }
    }
    
    func showAlertMessage(message:String) {
        let alertController = UIAlertController(title: "Alert", message: message, preferredStyle: .alert)
        let defaultAction = UIAlertAction(title: "OK", style: .default, handler: nil)
        alertController.addAction(defaultAction)
        present(alertController, animated: true, completion: nil)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
   
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let vc = segue.destination as! StudentResultViewController
        vc.studentDetailsObj = student
    }
}
