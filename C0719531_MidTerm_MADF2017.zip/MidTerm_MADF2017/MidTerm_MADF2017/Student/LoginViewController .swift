//
//  ViewController.swift
//  MidTerm_MADF2017
//
//  Created by moxDroid on 2017-10-20.
//  Copyright © 2017 moxDroid. All rights reserved.
//  Student ID :
//  Student Name :

import UIKit

class LoginViewController : UIViewController {

    @IBOutlet weak var txtFieldEmailId : UITextField!
    @IBOutlet weak var txtFieldPassword: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.navigationBar.isHidden = false
    }

    @IBAction func btnLoginTapped(sender : UIButton) {
        validateEmailAndPassword()
    }
    
    func validateEmailAndPassword() {
        if !isValidEmail(testStr: txtFieldEmailId.text!) {
            showAlertMessage(message: "Email Id is not valid.")
        }
        else if txtFieldEmailId.text == "kirtiparghi@gmail.com"  && txtFieldPassword.text == "111111"{
            storeEmailInUserDefaults()
            self.performSegue(withIdentifier: "studentEntrySegue", sender: self)
        }
        else {
            showAlertMessage(message: "Invalid Email id or password")
        }
    }
    
    func storeEmailInUserDefaults() {
        let userDefaults = UserDefaults.standard
        userDefaults.set(txtFieldEmailId.text, forKey: "email")
        userDefaults.synchronize()
    }
    
    func showAlertMessage(message:String) {
        let alertController = UIAlertController(title: "Alert", message: message, preferredStyle: .alert)
        let defaultAction = UIAlertAction(title: "OK", style: .default, handler: nil)
        alertController.addAction(defaultAction)
        present(alertController, animated: true, completion: nil)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

