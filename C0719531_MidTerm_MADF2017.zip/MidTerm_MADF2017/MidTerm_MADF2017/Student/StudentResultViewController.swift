//
//  StudentResultViewController.swift
//  MidTerm_MADF2017
//
//  Created by moxDroid on 2017-10-20.
//  Copyright © 2017 moxDroid. All rights reserved.
//  Student ID :
//  Student Name :

import UIKit

class StudentResultViewController: UIViewController {

    var studentDetailsObj: Student!
    
    @IBOutlet weak var lblID : UILabel!
    @IBOutlet weak var lblName : UILabel!
    @IBOutlet weak var lblEmailId : UILabel!
    @IBOutlet weak var lblBirthdate : UILabel!
    @IBOutlet weak var lblSubject1 : UILabel!
    @IBOutlet weak var lblSubject2 : UILabel!
    @IBOutlet weak var lblSubject3 : UILabel!
    @IBOutlet weak var lblSubject4 : UILabel!
    @IBOutlet weak var lblSubject5 : UILabel!
    
    @IBOutlet weak var lblTotal : UILabel!
    @IBOutlet weak var lblPercentage : UILabel!
    @IBOutlet weak var lblResult: UILabel!
    var total : Float!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        print(studentDetailsObj.studentEmail)
        
//        let logout = UIBarButtonItem(title: "Logout", style: .plain, target: self, action: #selector(logoutTapped))
//        self.navigationItem.leftBarButtonItem = logout
        
        let back = UIBarButtonItem(title: "Back", style: .plain, target: self, action: #selector(backTapped))
        self.navigationItem.rightBarButtonItem = back
        
        self.navigationController?.navigationBar.isHidden = false
        
        feedData()
        calculateTotalAndPercentage()
    }
    
    func calculateTotalAndPercentage() {
        
        total = Float(studentDetailsObj.subject1) + Float(studentDetailsObj.subject2) + Float(studentDetailsObj.subject3) + Float(studentDetailsObj.subject4) + Float(studentDetailsObj.subject5)
        lblTotal.text = "Total Marks is \(total!)"
        
        /*
         If marks of any two subjects < 45 then mark result as fail in red color and don’t calculate percentage & should display 0.0 value of percentage. All other criteria should display grade in green color.
         if per >= 95 then result = "A+"
         if per >=85 and per < 95 then result = "A" if per >=75 and per < 85 then result = "B+" if per >=65 and per < 75 then result = "B" if per >=55 and per < 65 then result = "C+" if per >=50 and per < 55 then result = "C" if per >=45 and per < 50 then result = "D+" if per <45 then result = “FAIL”
         */
        
        
        validateMarks()
    }
    
    func validateMarks() {
        if isAnyTwoSubLessThanfourtyFive() == 2 {
            lblResult.text = "Result is FAIL"
            lblResult.textColor = UIColor.red
            lblPercentage.text = "Percentage is 0.0"
        }
        else {
            
            let percetage: Float = (total/500)*100
            lblPercentage.text = "Percentage is \(percetage)"
            
            if percetage >= 95 {
                lblResult.text = "Result is A+"
                lblResult.textColor = UIColor.green
            }
            else if percetage >= 85 && percetage < 95 {
                lblResult.text = "Result is A"
                lblResult.textColor = UIColor.green
            }
            else if percetage >= 75 && percetage < 85 {
                lblResult.text = "Result is B+"
                lblResult.textColor = UIColor.green
            }
            else if percetage >= 65 && percetage < 75 {
                lblResult.text = "Result is B"
                lblResult.textColor = UIColor.green
            }
            else if percetage >= 55 && percetage < 65 {
                lblResult.text = "Result is C+"
                lblResult.textColor = UIColor.green
            }
            else if percetage >= 50 && percetage < 55 {
                lblResult.text = "Result is C"
                lblResult.textColor = UIColor.green
            }
            else if percetage >= 45 && percetage < 50 {
                lblResult.text = "Result is D+"
                lblResult.textColor = UIColor.green
            }
            else {
                lblResult.text = "Result is FAIL"
                lblResult.textColor = UIColor.red
            }
        }
    }
    
    func isAnyTwoSubLessThanfourtyFive() -> Int {
        var count: Int! = 0
        if Float(studentDetailsObj.subject1) < 45{
            count = count + 1
        }
        
        if Float(studentDetailsObj.subject2) < 45{
            count = count + 1
        }
        
        if Float(studentDetailsObj.subject3) < 45{
            count = count + 1
        }
        
        if Float(studentDetailsObj.subject4) < 45{
            count = count + 1
        }
        
        if Float(studentDetailsObj.subject5) < 45 {
            count = count + 1
        }
        return count
    }
    
    func feedData() {
        lblID.text = "ID is \(studentDetailsObj.studentId!)"
        lblName.text = "Name is \(studentDetailsObj.studentName!)"
        lblEmailId.text = "Email id is \(studentDetailsObj.studentEmail!)"
        lblBirthdate.text = "Birthdate is \(studentDetailsObj.studentBirthdate!)"
        lblSubject1.text = "Subject 1 is \(studentDetailsObj.subject1!)"
        lblSubject2.text = "Subject 2 is \(studentDetailsObj.subject2!)"
        lblSubject3.text = "Subject 3 is \(studentDetailsObj.subject3!)"
        lblSubject4.text = "Subject 4 is \(studentDetailsObj.subject4!)"
        lblSubject5.text = "Subject 5 is \(studentDetailsObj.subject5!)"
    }
    
    @objc func backTapped() {
        let storyboard : UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let vc : StudentEntryViewController = storyboard.instantiateViewController(withIdentifier: "StudentEntryVC") as! StudentEntryViewController
        vc.studentAlreadyExisted = studentDetailsObj
        let navigationController = UINavigationController(rootViewController: vc)
        self.present(navigationController, animated: true, completion: nil)
    }
    
    @objc func logoutTapped() {
        flushEmailInUserDefaults()
        let storyboard : UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let vc : LoginViewController = storyboard.instantiateViewController(withIdentifier: "loginVC") as! LoginViewController
        let navigationController = UINavigationController(rootViewController: vc)
        self.present(navigationController, animated: true, completion: nil)
    }

    func flushEmailInUserDefaults() {
        let userDefaults = UserDefaults.standard
        userDefaults.removeObject(forKey: "email")
        userDefaults.synchronize()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
}
