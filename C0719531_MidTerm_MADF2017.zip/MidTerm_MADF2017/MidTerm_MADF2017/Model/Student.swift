//
//  Student.swift
//  MidTerm_MADF2017
//
//  Created by moxDroid on 2017-10-20.
//  Copyright © 2017 moxDroid. All rights reserved.
//  Student ID : C0719531
//  Student Name : PARGHI KIRTIKUMAR H.

import Foundation

class Student {
    
    //Student id, Student name, Student email address, Student birthdate and Marks of 5 subjects
    
    var studentId: String!
    var studentName: String!
    var studentEmail : String!
    var studentBirthdate: String!
    var subject1: Float!
    var subject2: Float!
    var subject3: Float!
    var subject4: Float!
    var subject5: Float!
    
    init() {
        studentId = ""
        studentName = ""
        studentEmail = ""
        studentBirthdate = ""
        subject1 = 0
        subject2 = 0
        subject3 = 0
        subject4 = 0
        subject5 = 0
    }
    
    init(_ studentID:String, _ studentName: String, _ studentEmail : String, _ birthDate: String , _ subject1: Float, _ subject2: Float, _ subject3: Float, _ subject4: Float, _ subject5: Float){
        self.studentId = studentID
        self.studentName  = studentName
        self.studentEmail = studentEmail
        self.studentBirthdate = birthDate
        self.subject1 = subject1
        self.subject2 = subject2
        self.subject3 = subject3
        self.subject4 = subject4
        self.subject5 = subject5
    }
    
    
}
